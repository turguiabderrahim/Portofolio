window.addEventListener('scroll', e => {
    var el = document.getElementById('jsScroll');
    if(window.scrollY > 200) {
      el.classList.add('visible');
    } else {
      el.classList.remove('visible');
    }
  });
  
  function scrollToTop() {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  }

  var cursor =document.querySelector(".cursor");
        var cursor2 =document.querySelector(".cursor2");
        document.addEventListener("mousemove",function(e){
            cursor.style.cssText =  cursor2.style.cssText='left' +e.clientX +"px; top :"+e.clientY +"px;";
        })